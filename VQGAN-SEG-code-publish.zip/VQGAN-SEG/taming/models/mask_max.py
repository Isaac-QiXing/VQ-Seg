import cv2
import os
import numpy as np
import matplotlib.pyplot as plt

#
def Max_mask(img):
    img = cv2.imread(img)

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    ret, binary = cv2.threshold(gray, 156, 255, cv2.THRESH_BINARY)
    contours, hierarchy = cv2.findContours(binary, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
    # 找到最大区域并填充
    area = []

    for j in range(len(contours)):
        area.append(cv2.contourArea(contours[j]))

    max_idx = np.argmax(area)
    max_area = cv2.contourArea(contours[max_idx])

    for k in range(len(contours)):
        if k != max_idx:
            #print(k, 1)
            cv2.fillPoly(img, [contours[k]], (0,0,0))

    cv2.drawContours(img, contours[max_idx], -1, (0, 0, 0))

    return img


if __name__ == '__main__':
    img = "mask_img/007_mask.png"
    Max_mask(img)